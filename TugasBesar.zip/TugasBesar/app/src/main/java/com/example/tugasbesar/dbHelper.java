package com.example.tugasbesar;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.content.ContentValues;

import androidx.annotation.Nullable;


class dbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "datauser.db";
    private static final int DATABASE_VERSION = 1;
    //tabel 1
    private static final String TABLE_NAME = "datauser";
    private static final String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME +
            " (username VARCHAR(25) PRIMARY KEY," +
            " email VARCHAR(50)," +
            " telepon VARCHAR(25)," +
            " password VARCHAR(25));";
    private static final String DROP_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;
    //tabel 2
    private static final String TABLE_NAME2 = "ResepMakanan";
    private static final String CREATE_TABLE2 = "CREATE TABLE  " + TABLE_NAME2 +
            " (id INTEGER PRIMARY KEY AUTOINCREMENT," +
            " NamaMasakan VARCHAR(50) ," +
            " AsalMasakan VARCHAR(20)," +
            " Resep VARCHAR(100));";
    private static final String DROP_TABLE2 = "DROP TABLE IF EXISTS " + TABLE_NAME2;

    private Context context;



    public dbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(CREATE_TABLE);
            db.execSQL(CREATE_TABLE2);
        } catch (Exception e) {
            Message.message(context, "error " + e);
        }

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            Message.message(context, "OnUpgrade");
            db.execSQL(DROP_TABLE);
            db.execSQL(DROP_TABLE2);
            onCreate(db);
        } catch (Exception e) {
            Message.message(context, "" + e);
        }

    }

    public long insertData(String username, String email, String telepon, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("email", email);
        values.put("telepon", telepon);
        values.put("password", password);
        long id = db.insert(TABLE_NAME, null, values);
        return id;
    }

    public long insertResep(String NamaMasakan, String Asalmasakan,String Resep){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("NamaMasakan", NamaMasakan);
        values.put("Asalmasakan", Asalmasakan);
        values.put("Resep", Resep);
        long id2 = db.insert(TABLE_NAME2, null, values);
        return id2;

    }

    public int delete(String username) {
        SQLiteDatabase db = getWritableDatabase();
        String[] whereArgs = {username};
        int count = db.delete(TABLE_NAME, "username = ?", whereArgs);
        return count;
    }

    public int deleteresep(String NamaMasakan) {
        SQLiteDatabase db = getWritableDatabase();
        String[] whereArgs = {NamaMasakan};
        int count = db.delete(TABLE_NAME2, "NamaMasakan = ?", whereArgs);
        return count;
    }


    public int update(String username, String email, String telepon, String password) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("email", email);
        values.put("telepon", telepon);
        values.put("password", password);
        String[] whereArgs = {username};
        int count = db.update(TABLE_NAME, values, "username = ?", whereArgs);
        return count;
    }

    public int updateResepMakan(String id,String NamaMasakan, String Asalmasakan,String Resep) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("NamaMasakan", NamaMasakan);
        values.put("AsalMasakan", Asalmasakan);
        values.put("Resep", Resep);
        String[] whereArgs = {id};
        int count = db.update(TABLE_NAME2, values, "id= ?", whereArgs);
        return count;
    }
    public int updateNew(String username, String email, String telepon, String password, String old_username) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("email", email);
        values.put("telepon", telepon);
        values.put("password", password);
        String[] whereArgs = {old_username};
        int count = db.update(TABLE_NAME, values, "username = ?", whereArgs);
        return count;
    }


    public boolean login (String username, String password) throws SQLException{
        SQLiteDatabase db = getWritableDatabase();
        Cursor mCursor = db.rawQuery(" SELECT * FROM " + TABLE_NAME + " WHERE username=? AND password=? ",new String[]{username,password});
        if (mCursor !=null){
            if (mCursor.getCount()>0){
                return true;
            }
        }return false;
    }


}
