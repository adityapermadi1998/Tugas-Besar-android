package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class delete extends AppCompatActivity {
    private String isiDB;
    private TextView textDB;
    protected Cursor cursor;
    private Spinner SpDelete;
    dbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete);
        SpDelete = (Spinner) findViewById(R.id.spdelete);
        textDB = (TextView) findViewById(R.id.textDB);
        textDB.setMovementMethod(new ScrollingMovementMethod());
        dbHelper = new dbHelper(this);
        tampilData();
    }
    public void tampilData(){
        isiDB = "";
        //dbHelper = new dbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        cursor = db.query("datauser",null,null,null,null,null,null);
        //cursor.moveToFirst();
        int i = 0;
        try {
            while (cursor.moveToNext()){
                cursor.moveToPosition(i);
                isiDB +="|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"+
                        "| Username :"+cursor.getString(cursor.getColumnIndex("username"))+"\n"+
                        "| Email    :"+cursor.getString(cursor.getColumnIndex("email"))+"\n"+
                        "| Phone    :"+cursor.getString(cursor.getColumnIndex("telepon"))+"\n"+
                        "| Password :"+cursor.getString(cursor.getColumnIndex("password"))+"\n"+
                        "|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
                i++;
            }
        }finally {
            textDB.setText(isiDB);
            tampilSpinner();
            cursor.close();
        }
    }

    public void tampilSpinner(){
        ArrayList<String> arraySp = new ArrayList<>();
        dbHelper = new dbHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.query("datauser",null,null,null,null,null,null);
        int i = 0;
        try{
            while (cursor.moveToNext()){
                cursor.moveToPosition(i);
                arraySp.add(cursor.getString(cursor.getColumnIndex("username")));
                i++;
            }
        }finally {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, arraySp);
            SpDelete.setAdapter(adapter);
            SpDelete.setSelection(0);
            cursor.close();
        }
    }

    public void backberanda(View view) {
        if(SpDelete.getCount()==0){
            Message.message(getApplicationContext(),"Empty Databases !");
        } else {
            String name = SpDelete.getSelectedItem().toString();
            int a = dbHelper.delete(name);
            if(a<=0){
                Message.message(getApplicationContext(),"Delete Unsuccessful !");
                SpDelete.setSelection(0);
            } else{
                Message.message(this, "Delete Successful !");
                SpDelete.setSelection(0);
            }
        }
        tampilData();
    }

    public void beranda1(View view) {
        Intent goberanda = new Intent(delete.this, beranda.class);
        startActivity(goberanda);
        finish();
    }
}
