package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class UpdateResepMakanan extends AppCompatActivity {
    private EditText textNamaMasakan, textAsalMasakan, textResep, textNo;
    private TextView DBmakanan;
    private String NamaMasakan, AsalMasakan, Resep, isiDB,no;
    private Spinner spinnerSearch;
    protected Cursor cursor;
    dbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_resep_makanan);
        DBmakanan = (TextView) findViewById(R.id.DBmakanan);
        textNo = (EditText) findViewById(R.id.id);
        textNamaMasakan = (EditText) findViewById(R.id.NamaMasakan);
        textAsalMasakan = (EditText) findViewById(R.id.AsalMasakan);
        textResep = (EditText) findViewById(R.id.Resep);
        spinnerSearch=(Spinner)findViewById(R.id.spinner_search);
        DBmakanan.setMovementMethod(new ScrollingMovementMethod());
        setEnable(false);
        tampilData2();
    }

    public void tampilData2() {
        isiDB = "";
        dbHelper = new dbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        cursor = db.query("ResepMakanan", null, null, null, null, null, null);

        int i = 0;
        try {
            while (cursor.moveToNext()) {
                cursor.moveToPosition(i);
                isiDB +="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"+
                        "No :" + cursor.getString(cursor.getColumnIndex("id")) + "\n" +
                        "Nama Masakan :" + cursor.getString(cursor.getColumnIndex("NamaMasakan")) + "\n" +
                        "Asal Masakan :" + cursor.getString(cursor.getColumnIndex("AsalMasakan")) + "\n" +
                        "Resep :" + cursor.getString(cursor.getColumnIndex("Resep")) + "\n" +
                        "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";//pemberi batas
                i++;
            }
        } finally {
            DBmakanan.setText(isiDB);
            tampilspinner();
            cursor.close();
        }
    }
    public void tampilspinner(){
        ArrayList<String> arraySpinner= new ArrayList<>();
        dbHelper= new dbHelper(this);
        SQLiteDatabase db =dbHelper.getReadableDatabase();
        cursor= db.query("ResepMakanan",null,null,null,null,null,null);
        //cursor.moveToFirst();
        int i = 0 ;
        try{
            while(cursor.moveToNext()){
                cursor.moveToPosition(i);
                arraySpinner.add(cursor.getString(1));
                i++;
            }
        }finally {
            ArrayAdapter<String> adapterarray =new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arraySpinner);
            spinnerSearch.setAdapter(adapterarray);
            spinnerSearch.setSelection(0);
            cursor.close();
        }
    }

    public void setEnable(Boolean A){
       textNamaMasakan.setEnabled(A);
        textAsalMasakan.setEnabled(A);
        textResep.setEnabled(A);
    }


    public void update(View view) {
        no = textNo.getText().toString();
        NamaMasakan = textNamaMasakan.getText().toString();
        AsalMasakan = textAsalMasakan.getText().toString();
        Resep = textResep.getText().toString();
        if(no.isEmpty()||NamaMasakan.isEmpty()||AsalMasakan.isEmpty()||Resep.isEmpty()){
            Message.message(getApplicationContext(),"Enter Data");
        }
        else{
            int a= dbHelper.updateResepMakan(no,NamaMasakan,AsalMasakan,Resep);
            if (a<=0){
                Message.message(getApplicationContext(),"Unseccsesfull");
                textNamaMasakan.setText("");
                textAsalMasakan.setText("");
                textResep.setText("");
            }
            else {
                Message.message(getApplicationContext(),"Update");
                textNo.setText("");
                textNamaMasakan.setText("");
                textAsalMasakan.setText("");
                textResep.setText("");
                tampilData2();
                setEnable(false);
            }
        }
    }

    public void search(View view) {
        if (spinnerSearch.getCount() == 0) {
            Message.message(getApplicationContext(), "Can't find data !");
        }
        else {
            NamaMasakan = spinnerSearch.getSelectedItem().toString();
            String[] namaargs = {NamaMasakan};
            dbHelper = new dbHelper(this);
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            cursor = db.query("ResepMakanan", null, "NamaMasakan= ?", namaargs, null, null, null);

            int i = 0;
            try {
                while (cursor.moveToNext()) {
                    cursor.moveToPosition(i);
                    no = cursor.getString(cursor.getColumnIndex("id"));
                    NamaMasakan = cursor.getString(cursor.getColumnIndex("NamaMasakan"));
                    AsalMasakan = cursor.getString(cursor.getColumnIndex("AsalMasakan"));
                    Resep = cursor.getString(cursor.getColumnIndex("Resep"));
                    i++;
                }
            } catch (Exception e) {
                Message.message(getApplicationContext(), "error " + e);
            } finally {
                textNo.setText(no);
                textNamaMasakan.setText(NamaMasakan);
                textAsalMasakan.setText(AsalMasakan);
                textResep.setText(Resep);
                setEnable(true);
                cursor.close();
            }
        }
    }
    public void onBackPressed() {
        Intent Back = new Intent(UpdateResepMakanan.this,BuatResepMakanan.class);
        startActivity(Back);
        finish();
    }
}

