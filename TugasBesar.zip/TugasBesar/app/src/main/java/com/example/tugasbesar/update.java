package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

public class update extends AppCompatActivity {
    private EditText upusername,upemail,upphone,uppassword;
    private String username,email,telepon,password,old_username;
    private Cursor cursor;
    private Spinner spsearch;
    dbHelper dbHelper;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        upusername = (EditText) findViewById(R.id.newusername);
        upemail = (EditText) findViewById(R.id.newemail);
        upphone = (EditText) findViewById(R.id.newphone);
        uppassword = (EditText) findViewById(R.id.newpassword);
        spsearch = (Spinner) findViewById(R.id.spsearch);
        setEnable(false);
        dbHelper = new dbHelper(this);
        tampilSpinner();
        this.sharedPreferences = this.getSharedPreferences("userdetail",MODE_PRIVATE);
    }

    public void tampilSpinner(){
        ArrayList<String> arraySp = new ArrayList<>();
        dbHelper = new dbHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        cursor = db.query("datauser",null,null,null,null,null,null);
        int i = 0;
        try{
            while (cursor.moveToNext()) {
                cursor.moveToPosition(i);
                arraySp.add(cursor.getString(0));
                i++;
            }
        } finally {
            ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,arraySp);
            spsearch.setAdapter(adapter);
            spsearch.setSelection(0);
            cursor.close();
        }
    }

    public void search(View view) {
        if (spsearch.getCount() == 0) {
            Message.message(getApplicationContext(), "Can't find data !");
        }
        else {
            username = spsearch.getSelectedItem().toString();
            String[] namaargs = {username};
            dbHelper = new dbHelper(this);
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            cursor = db.query("datauser", null, "username = ?", namaargs, null, null, null);
            int i = 0;
            try {
                while (cursor.moveToNext()) {
                    cursor.moveToPosition(i);
                    username = cursor.getString(cursor.getColumnIndex("username"));
                    email = cursor.getString(cursor.getColumnIndex("email"));
                    telepon = cursor.getString(cursor.getColumnIndex("telepon"));
                    password = cursor.getString(cursor.getColumnIndex("password"));
                    i++;
                }
            } catch (Exception e) {
                Message.message(getApplicationContext(), "Error " + e);
            } finally {
                upusername.setText(username);
                upemail.setText(email);
                upphone.setText(telepon);
                uppassword.setText(password);
                setEnable(true);
                cursor.close();
            }
        }
    }

    public void backberanda(View view) {
        old_username = this.sharedPreferences.getString("username",null);
        username = upusername.getText().toString();
        email = upemail.getText().toString();
        telepon = upphone.getText() .toString();
        password = uppassword.getText().toString();
        if (username.isEmpty()||email.isEmpty()||telepon.isEmpty()||password.isEmpty()){
            Message.message(getApplicationContext(),"Please Enter Data");
        }else{

            if(username.matches(old_username)){
                int a = dbHelper.update(username,email,telepon,password);
                if (a<=0){
                    Message.message(getApplicationContext(),"Username didn't available!");
                } else {
                    Message.message(getApplicationContext(),"Data Updated !");
                    upusername.setText("");
                    upemail.setText("");
                    upphone.setText("");
                    uppassword.setText("");
                    setEnable(false);
                }
            } else {
                int b = dbHelper.updateNew(username,email,telepon,password,old_username);
                if (b<=0){
                    Message.message(getApplicationContext(),"Username didn't available!" + old_username);
                }else {
                    Message.message(getApplicationContext(),"Data Updated !");
                    upusername.setText("");
                    upemail.setText("");
                    upphone.setText("");
                    uppassword.setText("");
                    SharedPreferences.Editor editor = this.sharedPreferences.edit();
                    editor.putString("username",username);
                    editor.apply();
                    setEnable(false);
                }
            }
        } tampilSpinner();
    }

    public void setEnable(Boolean A){
        upusername.setEnabled(A);
        upemail.setEnabled(A);
        upphone.setEnabled(A);
        uppassword.setEnabled(A);
    }

    public void beranda2(View view) {
        Intent goberanda = new Intent(update.this, beranda.class);
        startActivity(goberanda);
        finish();
    }
}
