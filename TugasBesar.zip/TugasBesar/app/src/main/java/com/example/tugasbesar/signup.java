package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class signup extends AppCompatActivity {
    private EditText inuser,inemail,intelepon,inpassword,confirmpw;
    private String username,email,telepon,password,confirm;
    dbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        inuser = (EditText) findViewById(R.id.inuser);
        inemail = (EditText) findViewById(R.id.inemail);
        intelepon = (EditText) findViewById(R.id.inphone);
        inpassword = (EditText) findViewById(R.id.inpassword);
        confirmpw = (EditText) findViewById(R.id.confirmpw);
        dbHelper = new dbHelper(this);
    }

    public void backlogin(View view) {
        Intent gologin = new Intent(signup.this,activity_login.class);
        startActivity(gologin);
        finish();
    }

    public void createacc(View view) {
        username = inuser.getText().toString();
        email = inemail.getText().toString();
        telepon = intelepon.getText().toString();
        password = inpassword.getText().toString();
        confirm = confirmpw.getText().toString();
        if (username.isEmpty() || email.isEmpty() || telepon.isEmpty() || password.isEmpty()||confirm.isEmpty()) {
            Message.message(getApplicationContext(), "Please Fill All Column");
        } else {
            if(password.matches(confirm)){
                long id = dbHelper.insertData(username, email, telepon, password);
                if (id <= 0) {
                    Message.message(getApplicationContext(), "Username didn't available");
                    inuser.setText("");
                } else {
                    Message.message(getApplicationContext(), "Account Created");
                    inuser.setText("");
                    inemail.setText("");
                    intelepon.setText("");
                    inpassword.setText("");
                    confirmpw.setText("");
                    Intent gologin = new Intent(signup.this,activity_login.class);
                    startActivity(gologin);
                    finish();
                }
            } else  {
                Message.message(getApplicationContext(), "Password aren't matching");
            }
        }
    }
}
