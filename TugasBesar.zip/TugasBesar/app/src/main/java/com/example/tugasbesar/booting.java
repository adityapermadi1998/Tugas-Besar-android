package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class booting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_booting);
        new Handler().postDelayed(new Runnable(){
            @Override
            public void run() {
                Intent gologin = new Intent(booting.this, beranda.class);
                startActivity(gologin);
                finish();
            }
        }, 1500);
    }
}
