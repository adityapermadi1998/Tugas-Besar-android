package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;

public class BuatResepMakanan extends AppCompatActivity {
    private EditText textNamaMasakan, textAsalMasakan, textResep;
    private TextView DBmakanan;
    private String NamaMasakan, AsalMasakan, Resep, isiDB;
    private Spinner spinnerdelete;
    protected Cursor cursor;
    dbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buat_resep_makanan);
        DBmakanan = (TextView) findViewById(R.id.DBmakanan);
        textNamaMasakan = (EditText) findViewById(R.id.NamaMasakan);
        textAsalMasakan = (EditText) findViewById(R.id.AsalMasakan);
        textResep= (EditText) findViewById(R.id.Resep);
        spinnerdelete=(Spinner)findViewById(R.id.spinner_delete);
        DBmakanan.setMovementMethod(new ScrollingMovementMethod());
        dbHelper = new dbHelper(this);
        tampilData2();
    }

    public void tampilData2() {
        isiDB = "";
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        cursor = db.query("ResepMakanan", null, null, null, null, null, null);

        int i = 0;
        try {
            while (cursor.moveToNext()) {
                cursor.moveToPosition(i);
                isiDB +="~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"+
                        "No :" + cursor.getString(cursor.getColumnIndex("id")) + "\n" +
                        "Nama Masakan :" + cursor.getString(cursor.getColumnIndex("NamaMasakan")) + "\n" +
                        "Asal Masakan :" + cursor.getString(cursor.getColumnIndex("AsalMasakan")) + "\n" +
                        "Resep :" + cursor.getString(cursor.getColumnIndex("Resep")) + "\n" +
                        "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";//pemberi batas
                i++;
            }
        } finally {
            DBmakanan.setText(isiDB);
            tampilspinner();
            cursor.close();
        }
    }
    public void tampilspinner(){
        ArrayList<String> arraySpinner= new ArrayList<>();
        dbHelper= new dbHelper(this);
        SQLiteDatabase db =dbHelper.getReadableDatabase();
        cursor= db.query("ResepMakanan",null,null,null,null,null,null);
        int i = 0 ;
        try{
            while(cursor.moveToNext()){
                cursor.moveToPosition(i);
                arraySpinner.add(cursor.getString(cursor.getColumnIndex("NamaMasakan")));
                i++;
            }
        }finally {
            ArrayAdapter<String> adapterarray =new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, arraySpinner);
            spinnerdelete.setAdapter(adapterarray);
            spinnerdelete.setSelection(0);
            cursor.close();
        }
    }


    public void insert(View view) {
        NamaMasakan = textNamaMasakan.getText().toString();
        AsalMasakan = textAsalMasakan.getText().toString();
        Resep = textResep.getText().toString();
        if (NamaMasakan.isEmpty() || AsalMasakan.isEmpty() || Resep.isEmpty())
            Message.message(getApplicationContext(), "Enter All Text");
        else {
            long id2 = dbHelper.insertResep(NamaMasakan, AsalMasakan, Resep);
            if (id2 <= 0) {
                Message.message(getApplicationContext(), "Insertion Unseccesfull");
                textNamaMasakan.setText("");
                textAsalMasakan.setText("");
                textResep.setText("");
            } else {
                Message.message(getApplicationContext(), "Insert Succesfull");
                textNamaMasakan.setText("");
                textAsalMasakan.setText("");
                textResep.setText("");
            }
            tampilData2();
        }
    }

    public void delete(View view) {
        String name = spinnerdelete.getSelectedItem().toString();
        if(name.isEmpty()){
            Message.message(getApplicationContext(),"Enter Data");
        }
        else{
            int a=dbHelper.deleteresep(NamaMasakan);
            if (a<=0){
                Message.message(getApplicationContext(),"Unseccesfull");
                spinnerdelete.setSelection(0);
            }
            else{
                Message.message(this,"DELETE");
                spinnerdelete.setSelection(0);
            }
        }
        tampilData2();
    }

    public void inten_update(View view) {
        Intent intent =new Intent(BuatResepMakanan.this,UpdateResepMakanan.class);
        startActivity(intent);
    }
}

