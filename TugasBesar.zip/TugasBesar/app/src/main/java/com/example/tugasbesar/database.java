package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.TextView;

public class database extends AppCompatActivity {

    private String isiDB;
    private TextView textDB;
    protected Cursor cursor;
    dbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);
        textDB = (TextView) findViewById(R.id.textDB);
        textDB.setMovementMethod(new ScrollingMovementMethod());
        tampilData();
    }

    public void tampilData(){
        isiDB = "";
        dbHelper = new dbHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        cursor = db.query("datauser",null,null,null,null,null,null);
        int i = 0;
        try {
            while (cursor.moveToNext()){
                cursor.moveToPosition(i);
                isiDB +="|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"+
                        "| Username :"+cursor.getString(cursor.getColumnIndex("username"))+"\n"+
                        "| Email    :"+cursor.getString(cursor.getColumnIndex("email"))+"\n"+
                        "| Phone    :"+cursor.getString(cursor.getColumnIndex("telepon"))+"\n"+
                        "| Password :"+cursor.getString(cursor.getColumnIndex("password"))+"\n"+
                        "|~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
                i++;
            }
        }finally {
            textDB.setText(isiDB);
            cursor.close();
        }
    }

    public void beranda(View view) {
        Intent goberanda = new Intent(database.this, beranda.class);
        startActivity(goberanda);
        finish();
    }
}
