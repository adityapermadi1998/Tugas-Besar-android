package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class activity_login extends AppCompatActivity {private EditText inuser,inpw;
    private String user,password;
    dbHelper dbHelper;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        inuser = (EditText) findViewById(R.id.inputuser);
        inpw = (EditText) findViewById(R.id.inputpw);
        dbHelper = new dbHelper(this);

        sharedPreferences = getSharedPreferences("userdetail", MODE_PRIVATE);
        sharedPreferences.contains("username");
        sharedPreferences.contains("password");
    }

    public void login(View view) {
        user = inuser.getText().toString();
        password = inpw.getText().toString();
        try {
            if (user.isEmpty()||password.isEmpty()){
                Message.message(getApplicationContext(),"Error signing in, please try again");
            } else {
                if (user.length() > 0 && password.length() > 0) {
                    dbHelper = new dbHelper(this);
                    SQLiteDatabase db = dbHelper.getReadableDatabase();

                    if (dbHelper.login(user, password)) {
                        Message.message(getApplicationContext(), "Sign in Succes");
                        inuser.setText("");
                        inpw.setText("");

                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("username", user);
                        editor.apply();

                        Intent gobooting = new Intent(activity_login.this, booting.class);
                        startActivity(gobooting);
                        finish();
                    } else {
                        Message.message(getApplicationContext(), "Wrong Username / Password");
                    };
                }
            }
        } catch (Exception e) {
            Message.message(getApplicationContext(), "Error " + e);
        }
    }

    public void signup(View view) {
        Intent gosignup = new Intent(activity_login.this,signup.class);
        startActivity(gosignup);
        finish();
    }
}
