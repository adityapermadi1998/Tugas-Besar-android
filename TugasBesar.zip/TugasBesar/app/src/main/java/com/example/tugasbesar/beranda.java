package com.example.tugasbesar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class beranda extends AppCompatActivity {

    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beranda);

        TextView result = findViewById(R.id.detailuser);

        sharedPreferences = getSharedPreferences("userdetail",MODE_PRIVATE);
        result.setText(sharedPreferences.getString("username",null).toUpperCase());
    }
    public void update(View view) {
        Intent goupdate = new Intent(beranda.this,update.class);
        startActivity(goupdate);
    }


    public void backlogin(View view) {
        Intent gologin = new Intent(beranda.this,MainActivity.class);
        startActivity(gologin);
        finish();
    }

    public void opendb(View view) {
        Intent godb = new Intent(beranda.this,database.class);
        startActivity(godb);
    }

    public void delete(View view) {
        Intent godelete = new Intent(beranda.this,delete.class);
        startActivity(godelete);
    }

    public void goToResep(View view) {
        Intent goresep = new Intent(beranda.this,Resepmakanan.class);
        startActivity(goresep);
    }

    public void BuatResep(View view) {
        Intent BuatResep = new Intent(beranda.this,BuatResepMakanan.class);
        startActivity(BuatResep);
    }
}
